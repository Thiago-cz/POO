import java.util.ArrayList;

import TiposContas.Conta;

public class ListaContas {
    ArrayList<Conta> listaContas = new ArrayList<>();
}
